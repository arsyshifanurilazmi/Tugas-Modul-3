<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tugas Modul 1</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.0/font/bootstrap-icons.css"> 
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Navbar -->
    <?php include_once('navbar.php'); ?>
    <!-- Main -->
    <div class="bg-pink mt-5" id="main">
        <!-- Container -->
        <div class="container py-5 px-4">
            <div class="row">
                <div class="col-md-5 order-md-2">
                    <img class="img-fluid" src="assets/images/f69b988aae031ed52e547fb5fff2d6d5.jpg" alt="main logo">
                </div>
                <div class="col-md-7 order-md-1">
                    <h1 class="mt-4 display-3">Gourmandise</h1>
                    <p class="fs-5 mt-3">Selamat datang di dunia keindahan dan kelezatan di profil toko kue kami! 
                        Di sini, kami tidak hanya menyajikan kue-kue yang lezat, tetapi juga menghadirkan karya seni 
                        yang memukau bagi indera Anda. Setiap kue yang kami hasilkan merupakan perpaduan sempurna antara 
                        cita rasa yang luar biasa dan estetika yang memikat. Kami mengambil inspirasi dari tren dan gaya terkini 
                        untuk menciptakan kue-kue yang estetis dan memesona. Dengan sentuhan artistik dan perhatian terhadap detail, 
                        setiap kue menjadi karya seni yang unik dan menakjubkan. Dari desain yang elegan hingga yang penuh warna, 
                        kami menghadirkan beragam pilihan untuk memenuhi selera estetika Anda.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap Icons -->
    <div id="bg-end mt-5" id="main">
        <!-- Container -->
        <div class="container py-5 px-4">
            <div class="row">
                <div class="col-lg-6">
                    <img class="img-fluid" src="assets/images/50f557d0ee08e6c468d1f03a2637124c.jpg" alt="Bootstrap Icons">
                </div>
                <div class="col-lg-6">
                    <h2 class="display-5 mb-3">Keindahan 
                        <br/>Cita Rasa</h2>
                    <p class="fs-5"> 
                        <p>Selain keindahan visualnya, kue-kue kami juga menggugah selera dengan cita rasa yang istimewa. 
                            Kami menggunakan bahan-bahan berkualitas tinggi dan proses pembuatan yang teliti untuk menciptakan kue-kue yang lezat dan memuaskan. 
                            Setiap gigitan merupakan pengalaman yang memanjakan lidah dan menyenangkan hati.</p>
                        <p>Apakah Anda mencari kue untuk perayaan istimewa, acara khusus, atau hanya untuk memanjakan diri sendiri, 
                            kami siap membantu Anda menemukan kue yang sempurna. Kunjungi toko kami dan temukan keindahan dan 
                            kelezatan yang tak tertandingi dalam setiap karya kue kami.</p>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Produk -->
    <?php include_once('produk.php'); ?>
    <!-- Footer -->
    <?php include_once('footer.php'); ?>
</body>
</html>

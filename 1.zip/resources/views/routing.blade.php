<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tugas Modul 1</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.0/font/bootstrap-icons.css"> 
    <link rel="stylesheet" href="assets/css/style.css">

</head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Navbar -->
<nav class="navbar fixed-top navbar-expand-lg bg-brown" data-bs-theme="dark">
    <!-- Container -->
    <div class="container py-2 px-4">
        <!-- Navbar Brand -->
        <a href="#" class="navbar-brand mb-0 h1">
            <img class="img-fluid" src="assets/images/Desain tanpa judul.png" alt="logo" style="width: 40px;">
        </a>
    <!-- Navbar Toggler -->
    <button type="button" class="navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- Offcanvas -->
    <div class="offcanvas offcanvas-end bg-purple" id="offcanvasNavbar">
    <!-- Offcanvas Header -->
    <div class="offcanvas-header pb-0 px-4">
        <h5 class="offcanvas-title text-white" id="offcanvasNavbarLabel">Bootstrap</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <!-- Offcanvas Body -->
    <div class="offcanvas-body pt-0 px-4">
        <hr class="d-md-none text-white-50"> <!-- Horizontal Line -->
    <!-- Top Menu -->
            <ul class="navbar-nav flex-row flex-wrap">
                <li class="nav-item col-6 col-md-auto"><a href="#" class="nav-link active">Docs</a></li>
                <li class="nav-item col-6 col-md-auto"><a href="#" class="nav-link">Examples</a></li>
                <li class="nav-item col-6 col-md-auto"><a href="#" class="nav-link">Icons</a></li>
                <li class="nav-item col-6 col-md-auto"><a href="#" class="nav-link">Themes</a></li>
                <li class="nav-item col-6 col-md-auto"><a href="#" class="nav-link">Blog</a></li>
            </ul>
        <hr class="d-md-none text-white-50"> <!-- Horizontal Line -->
    <!-- Sosial Media -->
            <ul class="navbar-nav flex-row flex-wrap ms-md-auto">
                <li class="nav-item col-6 col-md-auto">
                    <a href="#" class="nav-link active">
                        <i class="bi-twitter"></i>
                        <small class="ms-2d-md-none">Twitter</small>
                    </a>
                </li>
                <li class="nav-item col-12 col-lg-auto">
                    <div class="vr d-none d-lg-flex h-100 mx-lg-2text-white"></div>
                    <hr class="d-lg-none my-2 text-white-50">
                </li>
<li class="nav-item">
    <!-- Dropdown -->
    <div class="dropdown" data-bs-theme="light">
        <button type="button" class="btn nav-link text-white dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="d-lg-none">Menu</span>Menu
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
            <li><h6 class="dropdown-header">Menu</h6></li>
            <li><button class="dropdown-item activebg-purple" type="button"><small>Profil<i class="bi-check"></i></small></button></li>
            <li><button class="dropdown-item" type="button"><small>Lokasi</small></button></li>
            <li><button class="dropdown-item" type="button"><small>Produk</small></button></li>
            <li><button class="dropdown-item" type="button"><small>Produk</small></button></li>
        </ul>
    </div>
</li>
<li class="nav-item col-12 col-lg-auto">
    <div class="vr d-none d-lg-flex h-100 mx-lg-2 text-white"></div>
    <hr class="d-lg-none my-2 text-white-50">
</li>
<li class="nav-item">
</li>
</ul>
</div>
</div>
</div>
</nav>
<!-- Main -->
<div class="bg-pink mt-5" id="main">
    <!-- Container -->
    <div class="container py-5 px-4">
        <div class="row">
            <div class="col-md-5 order-md-2">
                <img class="img-fluid" src="assets/images/f69b988aae031ed52e547fb5fff2d6d5.jpg" alt="main logo">
            </div>
            <div class="col-md-7 order-md-1">
                <h1 class="mt-4 display-3">Gourmandise</h1>
                    <p class="fs-5 mt-3">Selamat datang di dunia keindahan dan kelezatan di profil toko kue kami! 
                        Di sini, kami tidak hanya menyajikan kue-kue yang lezat, tetapi juga menghadirkan karya seni 
                        yang memukau bagi indera Anda. Setiap kue yang kami hasilkan merupakan perpaduan sempurna antara 
                        cita rasa yang luar biasa dan estetika yang memikat. Kami mengambil inspirasi dari tren dan gaya terkini 
                        untuk menciptakan kue-kue yang estetis dan memesona. Dengan sentuhan artistik dan perhatian terhadap detail, 
                        setiap kue menjadi karya seni yang unik dan menakjubkan. Dari desain yang elegan hingga yang penuh warna, 
                        kami menghadirkan beragam pilihan untuk memenuhi selera estetika Anda.</p>

            </div>
        </div>
    </div>
</div>
<!-- Bootstrap Icons -->
<div id="bg-end mt-5" id="main">
    <!-- Container -->
    <div class="container py-5 px-4">
        <div class="row">
            <div class="col-lg-6">
                <img class="img-fluid" src="assets/images/50f557d0ee08e6c468d1f03a2637124c.jpg" alt="Bootstrap Icons">
            </div>
            <div class="col-lg-6">
                <h2 class="display-5 mb-3">Keindahan 
                    <br/>Cita Rasa</h2>
                    <p class="fs-5"> 
                        <p>Selain keindahan visualnya, kue-kue kami juga menggugah selera dengan cita rasa yang istimewa. 
                        Kami menggunakan bahan-bahan berkualitas tinggi dan proses pembuatan yang teliti untuk menciptakan kue-kue yang lezat dan memuaskan. 
                        Setiap gigitan merupakan pengalaman yang memanjakan lidah dan menyenangkan hati.</p>
                        <p>Apakah Anda mencari kue untuk perayaan istimewa, acara khusus, atau hanya untuk memanjakan diri sendiri, 
                            kami siap membantu Anda menemukan kue yang sempurna. Kunjungi toko kami dan temukan keindahan dan 
                            kelezatan yang tak tertandingi dalam setiap karya kue kami.</p>
                    </p>
                    </div>
                </div>
            </div>
        </div>

<div class="bg-pink mt-5" id="main">
<div class="container text-center">
        <br>
        <h1 class="mt-4 display-3 text-center">Produk</h1>
        <br>
    </div>
    <div class="row">
        <div class="col-sm">
            <img src="assets/images/IMG_20240311_211155.jpg" width="100%">
        </div>
        <div class="col-sm">
            <img src="assets/images/IMG_20240311_211057.jpg" width="100%">
        </div>
        <div class="col-sm">
            <img src="assets/images/IMG_20240311_211215.jpg" width="100%">
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-sm">
            <img src="assets/images/IMG_20240311_211112.jpg" width="100%">
        </div>
        <div class="col-sm">
            <img src="assets/images/IMG_20240311_211141.jpg" width="100%">
        </div>
        <div class="col-sm">
            <img src="assets/images/IMG_20240311_211234.jpg" width="100%">
        </div>
    </div>
    <br>
        <div class="container d-flex justify-content-center align-items-center">
            <button type="button" class="btn bg-brown text-white btn-lg mb-3 me-md-3 px-4 py-3 ">Get Product</button>
        </div>
    <br>
</div>
<!-- Footer -->
<div id="footer" class="bg-end py-6">
    <!-- Container -->
    <div class="container py-5 px-4">
        <div class="row">
            
            <div class="col-lg-3 mb-5">
                <a href="#" class="logo text-decoration">
                    <div class="d-flex">
                        <img class="img-fluid" src="assets/images/Desain tanpa judul.png" style="width: 40px;">
                        <div class="fs-5 ms-2 text-black">Gourmandise</div>
                    </div>
                </a>
                <div class="mt-2 text-muted">
                    <div class="text-decoration">
                    <small>Selamatkan momen istimewa Anda dengan kelezatan kue-kue kami. Kunjungi toko kami hari ini dan nikmati pengalaman membeli kue yang tak tertandingi!</small>
                    </div>
                    </div>
                </div>
                <div class="col-6 col-lg-2 offset-lg-1 mb-5">
                    <h5>Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#">Home</a></li>
                        <li class="mb-2"><a href="#">Docs</a></li>
                        <li class="mb-2"><a href="#">Examples</a></li>
                        <li class="mb-2"><a href="#">Icons</a></li>
                        <li class="mb-2"><a href="#">Themes</a></li>
                        <li class="mb-2"><a href="#">Blog</a></li>
                        <li class="mb-2"><a href="#">Swag Store</a></li>
                    </ul>
                </div>
                <div class="col-6 col-lg-2 mb-5">
                    <h5>Guides</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#">Getting started</a></li>
                        <li class="mb-2"><a href="#">Starter template</a></li>
                        <li class="mb-2"><a href="#">Webpack</a></li>
                        <li class="mb-2"><a href="#">Parcel</a></li>
                    </ul>
                </div>
                <div class="col-6 col-lg-2 mb-5">
                    <h5>Product</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#">Choux Pastry</a></li>
                        <li class="mb-2"><a href="#">Croissant Pastry</a></li>
                        <li class="mb-2"><a href="#">Puff Pastry</a></li>
                        <li class="mb-2"><a href="#">Short Pastry</a></li>
                        <li class="mb-2"><a href="#">Phyllo Pastry</a></li>
                        <li class="mb-2"><a href="#">Danish Pastry</a></li>
                    </ul>
                </div>
                <div class="col-6 col-lg-2 mb-5">
                    <h5>Product</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#">Butter Cake</a></li>
                        <li class="mb-2"><a href="#">Pound Cake</a></li>
                        <li class="mb-2"><a href="#">Angel Food Cake</a></li>
                        <li class="mb-2"><a href="#">Chiffon Cake</a></li>
                        <li class="mb-2"><a href="#">Red Velvet Cake</a></li>
                        <li class="mb-2"><a href="#">Flourless Cake</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
